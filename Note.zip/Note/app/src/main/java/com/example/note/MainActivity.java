package com.example.note;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    EditText txt_zoom;
    Button btn_clear;
    Button settingsButton;
    Button smallerFont;
    //Button biggerFont;


    //supposed to be scroll zoom
    TextView zoomTextview;
    int mBaseDistance;
    float mRation = 1.0f;
    float mBaseRatio;
    final  static  float step = 200;
    float size = 30.0f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        zoomTextview = (TextView)findViewById(R.id.txt_zoom);

        //setting font size
        txt_zoom=findViewById(R.id.txt_zoom);
        txt_zoom.setTextSize(size);

        //clear text
        txt_zoom=findViewById(R.id.txt_zoom);
        btn_clear=findViewById(R.id.btn_clear);
        btn_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_zoom.getText().clear();
            }
        });

        //font smaller
        txt_zoom=findViewById(R.id.txt_zoom);
        smallerFont=findViewById(R.id.smallerFont);
        smallerFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                size = (size-2f);
                txt_zoom=findViewById(R.id.txt_zoom);
                txt_zoom.setTextSize(size);
            }
        });
        //font bigger
        txt_zoom=findViewById(R.id.txt_zoom);
        smallerFont=findViewById(R.id.biggerFont);
        smallerFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                size = (size+2f);
                txt_zoom=findViewById(R.id.txt_zoom);
                txt_zoom.setTextSize(size);
            }
        });




        //settings button
        settingsButton=findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSettings();
            }
        });

    }

    public void openSettings(){
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }



    public boolean onTouchEvent( MotionEvent event) {

        if(event.getPointerCount() ==2){
            int action = event.getAction();
            int pureAction = action & MotionEvent.ACTION_MASK;
            if(pureAction == MotionEvent.ACTION_POINTER_DOWN){
                mBaseDistance = getDistance(event);
                mBaseRatio = mRation;
            }
            else {
                float delta = (getDistance(event)-mBaseDistance)/step;
                float multi = (float)(Math.pow(2,delta));
                mRation = Math.min( 1024.0f,Math.max( 0.1f,multi * mBaseRatio));
                zoomTextview.setTextSize(mRation=13);
            }
        }
        return true;
    }

//on touch method
    int getDistance(MotionEvent motionEvent){
        int dx = (int)(motionEvent.getX(0)-motionEvent.getX(1));
        int dy = (int)(motionEvent.getY(0)-motionEvent.getY(1));
        return  (int)(Math.sqrt(dx * dx + dy * dy));
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return false;
    }
}